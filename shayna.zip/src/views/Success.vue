<template>

  <div class="success">
   <div class="d-flex success-checkout align-items-center justify-content-center">
    <div class="col col-lg-4 text-center">
            <img src="img/success-buy.png" alt="" width="294">
            <h3 class="mt-4">
                Suksess Terbayar !
            </h3>
            <p class="mt-2">
                    silahkan tunggu update terbaru dari kamu via email yang
            </p>
           <router-link to="/"> <a href="#" class="primary-btn pd-cart mt-3"> Back to Home  </a> </router-link> 
    </div>
</div>
  
  </div>
</template>

<script>
// @ is an alias to /src



export default {
  name: 'Success',
}
</script>
